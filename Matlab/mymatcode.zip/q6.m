d1 = input('Enter the value of d1: ');
d2 = input('Enter the value of d2: ');

r1 = ((d1^2 + d2^2))^1/2;
theta1 = atan(d2/d1);

d3 = input('Enter the value of d3: ');
d4 = input('Enter the value of d4: ');

r2 = ((d3^2 + d4^2))^1/2;
theta2 = 45;

d5 = input('Enter the value of d5: ');
d6 = input('Enter the value of d6: ');
r3 = ((d5^2 + d6^2))^1/2;
theta3 = atan(d6/d5);

N = input('Please enter the value of N: ');
squared_m = input('Please enter the value of M: ')^2;
squared_c = input('Please enter the  value of C: ')^2;
q1 = input('Please enter the value of Q: ');
q2 = input('Please enter the value of Q2: ');
q3 = input('Please enter the value of Q3: ');
argument1 = (q1 * sin(theta1))/r1^2 - (q2 * sin(theta2))/r2^2 + (q3 * sin(theta3))/r3^2;
argument2 = - (q1 * cos(theta1))/r1^2 - (q2 * cos(theta2))/r2^2 + (q3 * cos(theta3))/r3^2;
i = ((8.99 * 10^9 * N * squared_m)/squared_C) * argument1;
j = ((8.99 * 10^9 * N * squared_m)/squared_C) * argument2;
fprintf('%gi | %gj\n', i, j)