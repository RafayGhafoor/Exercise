m = 9.11*10^-31;
a_squared = (3.3 * 10^7) ^ 2;
abs_q = abs(-1.60 * 10^-19);
x = 2*(0.010);
E = (m*a_squared) / (abs_q * x);
fprintf('%g\n', E);