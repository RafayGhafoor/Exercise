m = 1.67 * 10^-27;
g = 9.81;
Z = 26;
e = 1.6 * 10^-19;
E = (56 * m * g) / (Z * e);
fprintf('E = %g N/C\n', E);
squared_C = input('Please enter the value of C: ') ^ 2;
N = input('Please enter the value of N: ');
squared_M = input('Please enter the value of M: ')^2;
epsilon = 8.85 * 10^-12 * squared_C/(N*squared_M);

sigma = epsilon * E;
fprintf('Sigma: %g\n', sigma);