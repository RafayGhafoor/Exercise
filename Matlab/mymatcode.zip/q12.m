m = 3.0 * 10^-5;
g = 9.81;
q = 4.0 * 10^-7;
E = ((m * g)/q)* tand(35);

fprintf('Electic Field =  %g N/C \n', E);